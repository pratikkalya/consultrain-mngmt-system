<?php $__env->startSection('content'); ?>

    <!-- <div class="row">
        <h1>You are logged in</h1>
    </div> -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>