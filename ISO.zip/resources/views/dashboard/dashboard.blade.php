@extends('layouts.app')

@section('content')

    <!-- <div class="row">
        <h1>You are logged in</h1>
    </div> -->
    
@endsection