  
<?php $__env->startSection('content'); ?>

<div>
  <h1><?php echo e($customer->name); ?></h1>      
</div>
<br>

<div class="pull-right">
    <a class="btn btn-primary" href="<?php echo e(route('customer.index')); ?>"> Back</a>
</div>
<div class="row">
    <div class="col-sm-8">
            <h1>Customer details</h1><br>
            <table class="table table-border" >
                    <tr class="table-primary" >
                        <th scope="row">Name</th>
                        <td><?php echo e($customer->cust_name); ?></td>
                    </tr>
                    <tr class="table-primary">
                        <th scope="row">Address</th>
                        <td>
                            <?php if($customer->street_name): ?>
                            <?php echo e($customer->street_name); ?>,
                            <?php endif; ?>
                            <?php if($customer->city): ?>
                            <?php echo e($customer->city); ?>,
                            <?php endif; ?>
                            <?php if($customer->state): ?>
                            <?php echo e($customer->state); ?>,
                            <?php endif; ?>
                            <?php if($customer->pincode): ?>
                            <?php echo e($customer->pincode); ?>,
                            <?php endif; ?>
                            <?php if($customer->country): ?>
                            <?php echo e($customer->country); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="table-primary">
                        <th scope="row">Phone number</th>
                        <td><?php echo e($customer->cust_phone_number); ?></td>
                    </tr>
                    <tr>
                        <th>Contact Person</th>
                        <td><?php echo e($customer->contact_person_name); ?></td>
                    </tr>
                    <tr>
                        <th>Contact Person Number</th>
                        <td><?php echo e($customer->contact_person_number); ?></td>
                    </tr>
                    <tr class="table-primary">
                        <th scope="row">Email</th>
                        <td><?php echo e($customer->cust_email); ?></td>
                    </tr>
            </table>
    </div>
   
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>