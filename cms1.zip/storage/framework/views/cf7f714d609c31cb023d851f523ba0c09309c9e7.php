<?php $__env->startSection('content'); ?>

<!-- <h2 style="padding: 2px;">AMC Details</h2>
<br>
<table class="table table-bordered">
        <tr>
            <th>Customer Name</th>
            <th>ISO Service</th>
            <th>Order No.</th>
            <th>Purchased Order</th>
            <th>Project Cost</th>
            <th>Period</th>
            <th>Planned Date</th>
        <th>Action</th> 
        <tr>
           <td><?php echo e($customer->cust_name); ?></td>
           <td><?php echo e($product->name); ?></td>
           <td><?php echo e($project->order_no); ?></td>
           <td><?php echo e($amc->purchase_ordr); ?></td>
           <td><?php echo e($amc->project_cost); ?></td>
           <td><?php echo e($amc->period); ?></td>
           <td><?php echo e($amc->start_plnd_dt); ?></td>
         <td>
                <a class="btn btn-primary" href="<?php echo e(route('customer.edit',$customer->id)); ?>">Edit</a>
            </td> 
        </tr>

</table> -->
<div class="panel panel-primary">
    <div class="panel-heading">
        <h4 class="panel-title">
            <b>AMC Details</b>
            <a class="btn btn-success" href="<?php echo e(route('projectmanagementamc.edit', ['id'=>$amc->id])); ?>" style="float: right;">Edit</a>
        </h4>
    </div>
    <!-- panel body -->
    <!-- <div id="accordionOne" class="panel-collapse collapse in"> -->
    <div class="panel-body">
        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-4">
                    <b>Customer Name :</b> <?php echo e($customer->cust_name); ?>

                </div>
                <div class="col-sm-4">
                    <b>ISO service :</b> <?php echo e($product->name); ?>

                </div>
                <div class="col-sm-4">
                    <b>Order No :</b> <?php echo e($project->order_no); ?>

                </div>
            </div>
            <br>
            <div class="row">
                <?php if($amc->project_cost): ?>
                <div class="col-sm-4">
                    <b>Project Cost :</b> <?php echo e($amc->project_cost); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->purchase_ordr): ?>
                <div class="col-sm-4">
                    <b>Purchase Order :</b> <?php echo e($amc->purchase_ordr); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->period): ?>
                <div class="col-sm-4">
                    <b>Period :</b> <?php echo e($amc->period); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

            <div class="row ">
                <?php if($amc->start_plnd_dt): ?>
                <div class="col-sm-4">
                    <b>Start Planned Date :</b> <?php echo e($amc->start_plnd_dt); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->start_actl_dt): ?>
                <div class="col-sm-4">
                    <b>Start Actual Date :</b> <?php echo e($amc->start_actl_dt); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

            <div class="row">
                <?php if($amc->visit1_dt): ?>
                <div class="col-sm-4">
                    <b>Visit One :</b> <?php echo e($amc->visit1_dt); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->payment_1): ?>
                <div class="col-sm-4">
                    <b>Payment One :</b> <?php echo e($amc->payment_1); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

            <div class="row ">
                <?php if($amc->visit2_dt): ?>
                <div class="col-sm-4">
                    <b>Visit Two :</b> <?php echo e($amc->visit2_dt); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->payment_2): ?>
                <div class="col-sm-4">
                    <b>Payment Two :</b> <?php echo e($amc->payment_2); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

            <div class="row ">
                <?php if($amc->visit3_dt): ?>
                <div class="col-sm-4">
                    <b>Visit Three :</b> <?php echo e($amc->visit3_dt); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->payment_3): ?>
                <div class="col-sm-4">
                    <b>Payment Three :</b> <?php echo e($amc->payment_3); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

            <div class="row ">
                <?php if($amc->visit4_dt): ?>
                <div class="col-sm-4">
                    <b>Visit Four :</b> <?php echo e($amc->visit4_dt); ?>

                </div>
                <?php endif; ?>
                <?php if($amc->payment_4): ?>
                <div class="col-sm-4">
                    <b>Payment Four :</b> <?php echo e($amc->payment_4); ?>

                </div>
                <?php endif; ?>
            </div>
            <br>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>