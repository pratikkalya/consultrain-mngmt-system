<?php $__env->startSection('content'); ?>

<h2 style="padding: 2px;">Project Information</h2>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('projectmanagement.create')); ?>"> Create New</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<div class="form-group">
    <input type="text" class="form-control" id="search" name="search" placeholder="Search By Name..">
</div>
<table class="table table-bordered" id="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Order Number</th>
            <th>Customer Name</th>
            <th>Project Leader</th>
            <th>Iso Service</th>
            <th>Agency Name</th>
            <th width="80px">Details</th>
        </tr>
    </thead>
    <tbody id="tbody">
        <?php $__currentLoopData = $projectmanagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectmanagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($projectmanagement->order_no); ?></td>
            <td><?php echo e($projectmanagement->customer->cust_name); ?></td>
            <td><?php echo e($projectmanagement->project_lead); ?></td>
            <td><?php echo e($projectmanagement->product->name); ?></td>
            <td><?php echo e($projectmanagement->agency->agency_name); ?></td>
            <td>
                <a class="btn btn-info" href="<?php echo e(route('projectmanagement.show',['id'=> $projectmanagement->id])); ?>">Show</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<?php echo $projectmanagements->links(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var order_no = null;
    var cust_name = null;
    var project_lead = null;
    var product_name = null;
    var agency_name = null;

    var loaded = false;
    $(document).ready(function () {
        var searchObject;
        var body = $("#tbody").html();
        // console.log(body);

        $.ajax({
            'async': false,
            'type': "GET",
            'global': false,
            'url': "http://127.0.0.1:8000/api/customers/search",
            'dataType': 'json',
            'success': function (data) {
                // console.log(data);
                loaded = true;
                var content = new Array();

                $.each(data.data, function (index, value) {
                    var search_details = new Object();

                    search_details.id = value.id;
                    search_details.order_no = value.order_no.toLowerCase();
                    search_details.cust_name = value.customer.cust_name.toLowerCase();
                    search_details.project_lead = value.project_lead.toLowerCase();
                    search_details.product_name = value.product.name.toLowerCase();
                    search_details.agency_name = value.agency.agency_name.toLowerCase();
                    content.push(search_details);
                });

                searchObject = content;
                console.log('fetched');
            }
        });
        $("#search").on('keyup', function () {
            var value = $(this).val();
            // console.log(value);
            if (value) {
                var myExp = new RegExp(value, "i");
                var content = '';
                var counter = 1;
                $.each(searchObject, function (key, val) {
                    // console.log(myExp);

                    if (val.order_no.search(myExp) != -1 || val.project_lead.search(myExp) != -
                        1 || val.cust_name.search(myExp) != -1 || val.product_name.search(myExp) !=
                        -1 || val.agency_name.search(myExp) != -1) {
                        // console.log(val);
                        content += '<tr><td>' + counter + '</td><td>' + val.order_no +
                            '</td><td>' + val.cust_name + '</td><td>' + val.project_lead +
                            '</td><td>' + val.product_name + '</td><td>' + val.agency_name +
                            '</td><td><a class="btn btn-info" href="http://127.0.0.1:8000/projectmanagement/' +
                            val.id + '">Show</a></td></tr>'
                    }
                    counter++;
                });
                $("#tbody").html(content);
            } else {
                console.log(body);
                $("#tbody").html(body);
            }
        });
    });

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>