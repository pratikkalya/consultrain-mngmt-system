  
<?php $__env->startSection('content'); ?>

<div>
  <h1><?php echo e($customer->name); ?></h1>      
</div>
<br>

<div class="row">
    <div class="col-md-12">
            <h4 class="c-grey-900 mB-20">Test details</h4>
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action">
                        <b>Customer/Comany Name :</b> <?php echo e($customer->cust_name); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Email:</b> <?php echo e($customer->cust_email); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Customer/Company Phone no:</b> <?php echo e($customer->cust_phone_number); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Contact Person :</b> <?php echo e($customer->contact_person_name); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Contact Person No :</b> <?php echo e($customer->contact_person_number); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Address :</b> <?php echo e($customer->street_name); ?>, <?php echo e($customer->city); ?>, <?php echo e($customer->state); ?>, <?php echo e($customer->pincode); ?>

                    </li>
                    <li class="list-group-item list-group-item-action">
                        <b>Country :</b><?php echo e($customer->country); ?>

                    </li>
                </ul>
    </div>
</div>
<br><br>
<div class="row">
    <div class="col-sm-6">
    <h4>Service details</h4><br>
    <table class="table table-bordered">
    <thead>
    <tr>
    <th>Service Name</th>
    <th>Agency Name</th>
    </tr>
    </thead>
    <tbody>
    <?php if($customer->projectManagements->count() != 0): ?>
        <?php $__currentLoopData = $customer->projectManagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($project->product->name); ?></td>
        <td><?php echo e($project->agency->agency_name); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
    <td>Empty</td>
    <td>Empty</td>
    </tr>
    <?php endif; ?>
    </tbody>
    </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>