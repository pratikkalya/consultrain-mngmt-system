<?php $__env->startSection('content'); ?>
<div class="row" style="padding: 3px 15px;margin:10px">
<h2 style="padding: 2px;">Project Information</h2>

        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('projectmanagement.create')); ?>"> Create New</a>
        </div>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<br><br>
<?php if(Auth::user()->user_type == 'admin'): ?>
<div class="form-group">
    <input type="text" class="form-control" id="search" name="search" placeholder="Search Here..">
</div>
<?php endif; ?>
<table class="table table-bordered" id="table" style="background:white"> 
    <thead>
        <tr>
            <th>Order Number</th>
            <th>Customer Name</th>
            <th>Project Leader</th>
            <th>ISO Service</th>
            <th>Agency Name</th>
            <th>Project Status</th>
            <th>Documentation Status</th>
            <th>Implimentation Status</th>
            <th>Audit Status</th>
            <th>Assessment Status</th>
            <th>Payment Status</th>
            <th width="80px">Details</th>
        </tr>
    </thead>
    <tbody id="tbody">
        <?php $__currentLoopData = $projectmanagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectmanagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($projectmanagement->order_no); ?></td>
            <td><?php echo e($projectmanagement->customer->cust_name); ?></td>
            <td><?php echo e($projectmanagement->user->name); ?></td>
            <td><?php echo e($projectmanagement->product->name); ?></td>
            <td><?php echo e($projectmanagement->agency->agency_name); ?></td>
            <td>
            <?php if($projectmanagement->project_status == 'open'): ?>
            <p style="color:blue;">Open</p>
            <?php elseif($projectmanagement->project_status == 'close'): ?>
            <p style="color:green;">Close</p>
            <?php endif; ?>
            </td>
            <td>
            <?php if($projectmanagement->documentation->doc_status == 'pending'): ?>
            <p style="color:red;">Pending</p>
            <?php elseif($projectmanagement->documentation->doc_status == 'complete'): ?>
            <p style="color:green;">Complete</p>
            <?php endif; ?>
            </td>
            <td>
            <?php if($projectmanagement->implementation->impl_status == 'pending'): ?>
            <p style="color:red;">Pending</p>
            <?php elseif($projectmanagement->implementation->impl_status == 'complete'): ?>
            <p style="color:green;">Complete</p>
            <?php endif; ?>
            </td>
            <td>
            <?php if($projectmanagement->audit->audit_status == 'pending'): ?>
            <p style="color:red;">Pending</p>
            <?php elseif($projectmanagement->audit->audit_status == 'complete'): ?>
            <p style="color:green;">Complete</p>
            <?php endif; ?>
            </td>
            <td>
            <?php if($projectmanagement->assessment->assassment_status == 'pending'): ?>
            <p style="color:red;">Pending</p>
            <?php elseif($projectmanagement->assessment->assassment_status == 'complete'): ?>
            <p style="color:green;">Complete</p>
            <?php endif; ?>
            </td>
            <td>
            <?php if($projectmanagement->payment->payment_status == 'pending'): ?>
            <p style="color:red;">Pending</p>
            <?php elseif($projectmanagement->payment->payment_status == 'complete'): ?>
            <p style="color:green;">Complete</p>
            <?php endif; ?>
            </td>
            <td>
                <a class="btn btn-info" href="<?php echo e(route('projectmanagement.show',['id'=> $projectmanagement->id])); ?>">Show</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $projectmanagements->links(); ?>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var order_no = null;
    var cust_name = null;
    var project_lead = null;
    var product_name = null;
    var agency_name = null;

    var loaded = false;
    $(document).ready(function () {
        var searchObject;
        var body = $("#tbody").html();
        // console.log(body);

        $.ajax({
            'async': false,
            'type': "GET",
            'global': false,
            'url': "<?php echo e(env('ROOT_URL')); ?>/api/customers/search",
            'dataType': 'json',
            'success': function (data) {
                console.log(data);
                loaded = true;
                var content = new Array();

                $.each(data.data, function (index, value) {
                    var search_details = new Object();

                    search_details.id = value.id;
                    search_details.order_no = value.order_no;
                    search_details.cust_name = value.customer.cust_name;
                    search_details.project_lead = value.user.name;
                    search_details.product_name = value.product.name;
                    search_details.agency_name = value.agency.agency_name;
                    search_details.project_status = value.project_status;
                    search_details.doc_status = value.documentation.doc_status;
                    search_details.impl_status = value.implementation.impl_status;
                    search_details.audit_status = value.audit.audit_status;
                    search_details.assessment_status = value.assessment.assassment_status;
                    search_details.payment_status = value.payment.payment_status;
                    content.push(search_details);
                });

                searchObject = content;
                console.log('fetched');
            }
        });
        $("#search").on('keyup', function () {
            var value = $(this).val();
            // console.log(value);
            if (value) {
                var myExp = new RegExp(value, "i");
                var content = '';
                var counter = 1;
                $.each(searchObject, function (key, val) {
                    // console.log(myExp);

                    if (val.order_no.search(myExp) != -1 || val.project_lead.search(myExp) != -
                        1 || val.cust_name.search(myExp) != -1 || val.product_name.search(myExp) !=
                        -1 || val.agency_name.search(myExp) != -1 || val.project_status.search(myExp) != -1 || val.doc_status.search(myExp) != -1 || val.impl_status.search(myExp) != -1 || val.audit_status.search(myExp) != -1 || val.assessment_status.search(myExp) != -1 || val.payment_status.search(myExp) != -1) {
                        console.log(val);
                        content += '<tr><td>' + val.order_no +
                            '</td><td>' + val.cust_name + '</td><td>' + val.project_lead +
                            '</td><td>' + val.product_name + '</td><td>' + val.agency_name +
                            '</td><td>' + val.project_status + '</td><td>' + val.doc_status + '</td><td>' + val.impl_status + '</td><td>' + val.audit_status + '</td><td>' + val.assessment_status + '</td><td>' + val.payment_status + '</td><td><a class="btn btn-info" href="<?php echo e(env('ROOT_URL')); ?>/projectmanagement/' +
                            val.id + '">Show</a></td></tr>'
                    }
                });
                $("#tbody").html(content);
            } else {
                console.log(body);
                $("#tbody").html(body);
            }
        });
    });

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>