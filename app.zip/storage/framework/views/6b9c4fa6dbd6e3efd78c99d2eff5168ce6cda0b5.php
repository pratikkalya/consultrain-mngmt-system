<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 50px 50px;min-height: calc(90vh - 60px);background-image: url(img/bg.jpg);background-repeat: no-repeat;background-size: cover;">

            <h1 class="text-center" style="position: absolute;top: 50%;text-align: center;font-size: 41px;transform: translateY(-50%);width: 90%;color:#00ccff;text-shadow: 10px 10px 10px black;">Welcome To Consultrain Management Services</h1>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>