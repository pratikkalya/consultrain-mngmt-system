  
<?php $__env->startSection('content'); ?>
<div class="row" style="padding: 3px 15px;margin:10px">
      <div class ="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="margin-right: 320px;">
         <h1>Add Customer</h1>
         <form action="<?php echo e(route('customer.store')); ?>" method="post">
              <?php if($errors->any()): ?>
                 <div class="alert alert-danger">
                     <ul>
                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><?php echo e($error); ?></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                  </div>
              <?php endif; ?>
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                 <label for="cust_name">Name</label>
                 <input type="text" class="form-control" id="cust_name" placeholder="Enter Name" name="cust_name" required autofocus pattern="[A-Za-z ]{1,100}">
              </div>
              <div class="form-group">
                 <label for="cust_email">Email address</label>
                 <input type="email" class="form-control" id="cust_email" placeholder="Enter email" name="cust_email" pattern="[a-z0-9._%+-]{2,15}+@[a-z0-9.-]{2,15}+.[a-z]{2,15}">
              </div>
              <div class="form-group">
                  <label for="cust_phone_number">Phone Number</label>
                  <input type="text" class="form-control" id="cust_phone_number" placeholder="Enter Number"  name="cust_phone_number"   required autofocus pattern="[0-9]{1,10}">
                  <span class="help-block small">( enter 10 number only )</span>
              </div>
              <div class="form-group">
                <label for="contact_person_name">Contact Person</label>
                <input type="text" class="form-control" id="contact_person_name" placeholder="Contact Person" name="contact_person_name" pattern="[A-Z a-z]{1,100}"> 
             </div>
             <div class="form-group">
                <label for="contact_person_number">Contact Person Number</label>
                <input type="text" class="form-control" id="contact_person_number" placeholder="Contact Person Number" name="contact_person_number"  pattern="[0-9]{1,10}">
                  <span class="help-block small">( enter 10 number only )</span>
             </div>
             <div class="form-group">
                <label for="street_name">Street Name</label>
                <input type="text" class="form-control" id="street_name" placeholder="Street Name" name="street_name" required>
             </div>

              <div class="col-sm-6" style="padding: 0px;">
                 <div class="form-group">
                     <label for="city">City</label>
                     <input type="text" class="form-control" id="city" placeholder="City" name="city" style="width: 230px;" required>
                 </div>
              </div>
              <div class="col-sm-6">
                  <div class="form-group">
                     <label for="state">State</label>
                     <input type="text" class="form-control" id="state" placeholder="State" name="state" style="width: 235px;" required>
                  </div>
               </div>

              <div class="col-sm-6" style="padding: 0px;">
                 <div class="form-group">
                     <label for="pincode">Pincode</label>
                     <input type="text" class="form-control" id="pincode" placeholder="Pincode" name="pincode" style="width: 230px;"  required autofocus pattern="[0-9]{1,6}">
                 </div>
              </div>
              
               <div class="col-sm-6">
                  <div class="form-group">
                      <label for="country">Country</label>
                      <input type="text" class="form-control" id="country" placeholder="Country" name="country" style="width: 235px;"  required>
                  </div>
               </div>
              <div>
                 <button type="submit" class="btn btn-primary">Submit</button>
              </div>
          </form>
     </div>
    <br>
    <br>
</div>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>